"""MeteoRisco — config package."""
from .settings import settings, Settings

__all__ = ["settings", "Settings"]
