"""MeteoRisco — package init."""
